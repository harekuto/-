package net.execheinz.upgrader.cases;

import static org.junit.jupiter.api.Assertions.*;

import java.util.HashSet;
import java.util.Set;
import org.junit.jupiter.api.Test;

final class CaseCatalogTest {
    private static final Set<String> RARITIES = Set.of("COMMON","UNCOMMON","RARE","EPIC","LEGENDARY","MYTHIC","MASTER","RNG");

    @Test
    void bundledCatalogIsCompleteStableAndEconomicallyValid() {
        assertEquals(224, CaseCatalog.all().size());
        var ids = new HashSet<String>();
        var orders = new HashSet<Integer>();
        for (CaseDefinition c : CaseCatalog.all()) {
            assertTrue(ids.add(c.id()), "duplicate id " + c.id());
            assertTrue(orders.add(c.order()), "duplicate order " + c.order());
            assertSame(c, CaseCatalog.byId(c.id()));
            assertTrue(c.cost() > 0, c.id());
            assertFalse(c.nameRu().isBlank(), c.id());
            assertFalse(c.nameEn().isBlank(), c.id());
            assertFalse(c.descriptionRu().isBlank(), c.id());
            assertFalse(c.descriptionEn().isBlank(), c.id());
            assertFalse(c.category().isBlank(), c.id());
            assertTrue(RARITIES.contains(c.rarity()), c.id() + " rarity=" + c.rarity());
            assertTrue(c.jackpot() >= 0D && c.jackpot() <= 1D, c.id());
            assertNotNull(c.keywords());
            if (c.rewardMode().equals("themed")) {
                assertTrue(c.returnMin() > 0D && c.returnMin() <= c.returnMax(), c.id());
                assertTrue(c.returnMax() <= 2D, c.id());
            }
        }
        assertEquals("all_mods", CaseCatalog.byId("all_mods").rewardMode());
        assertEquals("absolute_random", CaseCatalog.byId("absolute_random").rewardMode());
    }
}
