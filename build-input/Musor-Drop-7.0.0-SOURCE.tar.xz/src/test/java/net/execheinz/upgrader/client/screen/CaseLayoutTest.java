package net.execheinz.upgrader.client.screen;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

final class CaseLayoutTest {
    @Test
    void largeCardsFitAndDoNotOverlap() {
        assertEquals(4, CaseLayout.PAGE_SIZE);
        for (int i = 0; i < CaseLayout.PAGE_SIZE; i++) {
            CaseLayout.Rect a = CaseLayout.card(i);
            assertTrue(a.x() >= 65, "Cards must stay clear of the navigation rail");
            assertTrue(a.y() >= 59);
            assertTrue(a.x() + a.w() <= CaseLayout.GUI_W - 10, "Cards need a right breathing margin");
            assertTrue(a.y() + a.h() < CaseLayout.prevButton().y(), "Cards must stay above controls");
            for (int j = i + 1; j < CaseLayout.PAGE_SIZE; j++) {
                assertFalse(a.overlaps(CaseLayout.card(j)), "Cards overlap: " + i + " and " + j);
            }
        }
    }

    @Test
    void catalogHeaderFilterDoesNotTouchGridOrPrimaryAction() {
        CaseLayout.Rect filter = CaseLayout.categoryButton();
        assertTrue(filter.x() >= 280);
        assertTrue(filter.x() + filter.w() <= CaseLayout.GUI_W - 10);
        assertTrue(filter.y() + filter.h() < CaseLayout.card(0).y());
        assertFalse(filter.overlaps(CaseLayout.openButton()));
    }

    @Test
    void navigationAndPrimaryActionStayInsideContentZone() {
        CaseLayout.Rect[] rects = {
            CaseLayout.prevButton(), CaseLayout.nextButton(),
            CaseLayout.selectedPanel(), CaseLayout.openButton()
        };
        for (CaseLayout.Rect r : rects) {
            assertTrue(r.x() >= 60 && r.y() >= 0);
            assertTrue(r.x() + r.w() <= CaseLayout.GUI_W - 10);
            assertTrue(r.y() + r.h() <= 172, "Case controls must remain above inventory separator");
        }
        assertFalse(CaseLayout.prevButton().overlaps(CaseLayout.nextButton()));
        assertFalse(CaseLayout.nextButton().overlaps(CaseLayout.selectedPanel()));
        assertFalse(CaseLayout.selectedPanel().overlaps(CaseLayout.openButton()));
        assertTrue(CaseLayout.openButton().w() >= 100, "Primary action must remain visually dominant");
        assertTrue(CaseLayout.selectedPanel().w() >= 120, "Selected case summary needs readable width");
    }

    @Test
    void sevenZeroGridGeometryIsStable() {
        assertEquals(360, CaseLayout.GUI_W);
        assertEquals(252, CaseLayout.GUI_H);
        assertEquals(65, CaseLayout.card(0).x());
        assertEquals(59, CaseLayout.card(0).y());
        assertEquals(209, CaseLayout.card(1).x());
        assertEquals(109, CaseLayout.card(2).y());
        assertEquals(348, CaseLayout.card(3).x() + CaseLayout.card(3).w());
        assertEquals(154, CaseLayout.card(3).y() + CaseLayout.card(3).h());
    }

    @Test
    void gridUsesReadableLargeCardSpacing() {
        CaseLayout.Rect a = CaseLayout.card(0);
        CaseLayout.Rect b = CaseLayout.card(1);
        CaseLayout.Rect d = CaseLayout.card(2);
        assertEquals(5, b.x() - (a.x() + a.w()));
        assertEquals(5, d.y() - (a.y() + a.h()));
        assertTrue(a.w() >= 139);
        assertTrue(a.h() >= 45);
    }

    @Test
    void actionStripHasAtLeastFourPixelGaps() {
        assertTrue(CaseLayout.nextButton().x() - (CaseLayout.prevButton().x() + CaseLayout.prevButton().w()) >= 4);
        assertTrue(CaseLayout.selectedPanel().x() - (CaseLayout.nextButton().x() + CaseLayout.nextButton().w()) >= 4);
        assertTrue(CaseLayout.openButton().x() - (CaseLayout.selectedPanel().x() + CaseLayout.selectedPanel().w()) >= 4);
    }
}
