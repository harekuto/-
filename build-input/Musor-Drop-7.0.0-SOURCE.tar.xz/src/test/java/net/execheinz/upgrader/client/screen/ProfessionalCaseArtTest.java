package net.execheinz.upgrader.client.screen;

import static org.junit.jupiter.api.Assertions.*;

import java.awt.image.BufferedImage;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Set;
import javax.imageio.ImageIO;
import org.junit.jupiter.api.Test;

final class ProfessionalCaseArtTest {
    private static final Set<String> CATEGORIES = Set.of(
        "armor", "biomes", "building", "collections", "combat", "decor", "deep_dark", "end",
        "exploration", "farming", "food", "magic", "master", "mining", "mobs", "modded",
        "mythic", "nether", "ocean", "pro", "random", "redstone", "structures", "survival",
        "tools", "treasure", "village", "weapons"
    );

    @Test
    void allCaseFacesUseProfessionalThirtyTwoPixelMaterials() throws Exception {
        Path root = Path.of("src/main/resources/assets/musordrop/textures/item/cases");
        for (String id : CATEGORIES) {
            Path file = root.resolve(id + ".png");
            assertTrue(Files.isRegularFile(file), id);
            BufferedImage image = ImageIO.read(file.toFile());
            assertNotNull(image, id);
            assertEquals(32, image.getWidth(), id);
            assertEquals(32, image.getHeight(), id);
        }
        BufferedImage metal = ImageIO.read(root.resolve("metal.png").toFile());
        assertNotNull(metal);
        assertEquals(32, metal.getWidth());
        assertEquals(32, metal.getHeight());
    }

    @Test
    void rebuiltCaseModelContainsPremiumLayering() throws Exception {
        String json = Files.readString(Path.of("src/main/resources/assets/musordrop/models/item/case_models/base_case.json"));
        long elementCount = json.split("\\\"from\\\"").length - 1L;
        assertTrue(elementCount >= 16, "case model should have layered body, lid, corner braces and latch");
        assertTrue(json.contains("1.02"), "GUI display should use the enlarged professional presentation scale");
    }
}
