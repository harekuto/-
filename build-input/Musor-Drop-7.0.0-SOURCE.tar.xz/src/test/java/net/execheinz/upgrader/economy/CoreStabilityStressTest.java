package net.execheinz.upgrader.economy;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Random;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;

/** 12,000 deterministic property-style test cases for transaction math boundaries. */
final class CoreStabilityStressTest {
    private static final int CASES = 12_000;

    @TestFactory
    Stream<DynamicTest> deterministicEconomyAndOddsFuzz() {
        return IntStream.range(0, CASES).mapToObj(i -> DynamicTest.dynamicTest("stability-" + i, () -> {
            Random r = new Random(0x4D55534F5244524FL ^ (long)i * 0x9E3779B97F4A7C15L);

            double input = Math.pow(10D, r.nextDouble() * 10D - 2D);
            double target = Math.pow(10D, r.nextDouble() * 10D - 2D);
            double chance = EconomyMath.upgradeChance(input, target, 0.92D, 0.001D, 0.92D);
            assertTrue(Double.isFinite(chance));
            assertTrue(chance >= 0.001D && chance <= 0.92D);

            long cap = 1_000L + Math.floorMod(r.nextLong(), 1_000_000_000L);
            long current = Math.floorMod(r.nextLong(), cap + 1L);
            long amount = Math.floorMod(r.nextLong(), 2_000_000_000L);
            long added = EconomyMath.saturatingAddPositive(current, amount, cap);
            assertTrue(added >= current);
            assertTrue(added <= cap);
            assertEquals(cap - Math.min(cap, Math.max(0L, current)), EconomyMath.remainingCapacity(current, cap));

            double stackValue = Math.pow(10D, r.nextDouble() * 11D - 2D);
            double rate = r.nextDouble();
            long payout = EconomyMath.sellPayout(stackValue, rate, cap);
            assertTrue(payout >= 0L);
            assertTrue(payout <= cap);

            int maxStack = 1 + r.nextInt(64);
            int count = EconomyMath.rewardCount(stackValue, Math.max(0.001D, target), maxStack);
            assertTrue(count >= 1 && count <= maxStack);
        }));
    }
}
