package net.execheinz.upgrader.economy;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

final class EconomyMathBoundaryTest {
    @Test void rejectsNonFiniteAndInvalidInputs() {
        assertEquals(0D, EconomyMath.upgradeChance(Double.NaN, 1, .92, .001, .92));
        assertEquals(0D, EconomyMath.upgradeChance(1, 0, .92, .001, .92));
        assertEquals(0L, EconomyMath.sellPayout(Double.POSITIVE_INFINITY, .72, 1000));
        assertEquals(0L, EconomyMath.sellPayout(100, Double.NaN, 1000));
        assertEquals(1, EconomyMath.rewardCount(Double.NaN, 1, 64));
    }

    @Test void saturatesWithoutOverflow() {
        assertEquals(1000L, EconomyMath.saturatingAddPositive(999L, Long.MAX_VALUE, 1000L));
        assertEquals(0L, EconomyMath.saturatingAddPositive(-5L, 0L, 1000L));
        assertEquals(0L, EconomyMath.remainingCapacity(Long.MAX_VALUE, 1000L));
    }
}
